import java.util.List;

public class CategoryManager {
    private CategoryWriter categoryWriter;
    private CategoryReader categoryReader;

    public CategoryManager(CategoryWriter categoryWriter, CategoryReader categoryReader) {
        this.categoryWriter = categoryWriter;
        this.categoryReader = categoryReader;

        // Default categories
        categoryWriter.addCategory(new Category(1, "Technology"));
        categoryWriter.addCategory(new Category(2, "Lifestyle"));
        categoryWriter.addCategory(new Category(3, "Health"));
    }

    public void displayCategories() {
        List<Category> categories = categoryReader.getCategories();
        if (categories.isEmpty()) {
            System.out.println("No categories available.");
        } else {
            System.out.println("\n=== Available Categories ===");
            for (Category category : categories) {
                System.out.println("- " + category.getName());
            }
        }
    }
}