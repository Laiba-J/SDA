
public class BlogPost {
    private BlogPost next;

    public BlogPost getNext() {
        return next;
    }

    public void setNext(BlogPost next) {
        this.next = next;
    }
}