public interface CategoryWriter {
    void addCategory(Category category);
}