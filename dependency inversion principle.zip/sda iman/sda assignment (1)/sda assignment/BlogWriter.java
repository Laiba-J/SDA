public interface BlogWriter {
    void addBlog(Blog blog);
}