import java.util.List;

public interface CategoryRepository extends CategoryWriter, CategoryReader {
    void addCategory(Category category);
    List<Category> getCategories();
}