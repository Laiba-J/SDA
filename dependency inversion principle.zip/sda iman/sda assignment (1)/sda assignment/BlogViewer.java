import java.util.List;

public class BlogViewer {
    private BlogManager blogManager;

    public BlogViewer(BlogManager blogManager) {
        this.blogManager = blogManager;
    }

    public void viewAllBlogs() {
        List<Blog> blogs = blogManager.getBlogs();
        if (blogs.isEmpty()) {
            System.out.println("No blogs available.");
            return;
        }
        for (Blog blog : blogs) {
            System.out.println("ID: " + blog.getId() + " | Title: " + blog.getTitle());
        }
    }
}