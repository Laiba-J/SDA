public interface ContentHolder {
    String getContent();
}