public interface Titled {
    String getTitle();
}