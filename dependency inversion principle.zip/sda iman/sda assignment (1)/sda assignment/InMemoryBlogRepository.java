import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InMemoryBlogRepository implements BlogRepository {
    private List<Blog> blogs = new ArrayList<>();

    @Override
    public void addBlog(Blog blog) {
        blogs.add(blog);
    }

    @Override
    public List<Blog> getBlogs() {
        return blogs;
    }

    @Override
    public Optional<Blog> getBlogById(int blogId) {
        return blogs.stream()
                .filter(blog -> blog.getId() == blogId)
                .findFirst();
    }
}