public class Blog implements Identifiable, Titled, ContentHolder, Categorizable {
    private int id;
    private String title;
    private String content;
    private String category;

    public Blog(int id, String title, String content, String category) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.category = category;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getContent() {
        return content;
    }

    @Override
    public String getCategory() {
        return category;
    }
}