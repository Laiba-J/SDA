import java.util.List;
import java.util.Optional;

public class BlogManager {
    private BlogWriter blogWriter;
    private BlogReader blogReader;

    public BlogManager(BlogWriter blogWriter, BlogReader blogReader) {
        this.blogWriter = blogWriter;
        this.blogReader = blogReader;
    }

    public void addBlog(String title, String content, String category) {
        int id = blogReader.getBlogs().size() + 1;
        Blog blog = new Blog(id, title, content, category);
        blogWriter.addBlog(blog);
        System.out.println("Blog added successfully!");
    }

    public List<Blog> getBlogs() {
        return blogReader.getBlogs();
    }

    public Optional<Blog> getBlogById(int blogId) {
        return blogReader.getBlogById(blogId);
    }

    public void displayBlogs() {
        List<Blog> blogs = blogReader.getBlogs();
        if (blogs.isEmpty()) {
            System.out.println("No blog posts available.");
        } else {
            for (Blog blog : blogs) {
                System.out.println("Blog ID: " + blog.getId() + ", Title: " + blog.getTitle());
            }
        }
    }
}