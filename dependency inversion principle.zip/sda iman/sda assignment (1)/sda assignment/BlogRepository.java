import java.util.List;
import java.util.Optional;

public interface BlogRepository extends BlogWriter, BlogReader {
    void addBlog(Blog blog);
    List<Blog> getBlogs();
    Optional<Blog> getBlogById(int blogId);
}