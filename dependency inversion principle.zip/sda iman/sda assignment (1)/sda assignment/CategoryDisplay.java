import java.util.List;

public class CategoryDisplay {
    public void displayCategories(List<Category> categories) {
        System.out.println("\n=== Available Categories ===");
        for (Category category : categories) {
            System.out.println("- " + category.getName());
        }
    }
}
