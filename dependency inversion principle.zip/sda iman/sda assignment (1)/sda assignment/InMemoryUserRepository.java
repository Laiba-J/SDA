import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class InMemoryUserRepository implements UserRepository {
    private Map<String, User> users = new HashMap<>();

    @Override
    public void addUser(User user) {
        users.put(user.getUsername(), user);
    }

    @Override
    public Optional<User> getUserByUsername(String username) {
        return Optional.ofNullable(users.get(username));
    }
}