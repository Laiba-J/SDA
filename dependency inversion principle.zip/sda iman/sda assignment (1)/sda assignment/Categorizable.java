public interface Categorizable {
    String getCategory();
}