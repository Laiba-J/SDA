import java.util.Optional;

public interface UserRepository {
    void addUser(User user);
    Optional<User> getUserByUsername(String username);
}