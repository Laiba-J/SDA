import java.util.List;

public interface CategoryReader {
    List<Category> getCategories();
}